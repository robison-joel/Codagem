<html>
  <title>exemplo de figuras(cadastro)</title>
  <body>
    cadastro de produtos
	<form action="grava.php" method="get">
	  <br>nome:<input type="text" name="nome">
	  <br>estoque:<input type="text" name="estoque">
	  <br>imagem<input type="file" name="figura">
	  <br><br> <input type="submit" value="gravar">
	</form>
  </boby>
</html>