<html>
<head><title>Trabalho de PHP</title></head>
<body>
	<center>
	<font size="5" color="red" face="verdana"> Prova G1 </font>
	<br><a href="cadastro.html">
	<font size="4" color="black" face="verdana"> Mauricio Westrupp </font></a>
	<br><hr>
	<br>
	<form action="gravar.php" method="get" name="formulario">
	<table>
	<tr><td>Nome: </td><td><input type="text" name="nome" size="33" maxlenght="15"></td></tr>
	<tr><td>Ra�a: </td><td><input type="text" name="raca" size="33" maxlenght="25"></td></tr>
	<tr><td>Proprietario: </td><td><input type="text" name="proprietario" size="33" maxlenght="15"></td></tr>
	<tr><td>Email: </td><td><input type="text" name="email" size="33" maxlenght="15"></td></tr>
	<tr><td>Idade: </td><td><input type="text" name="idade" size="33" maxlenght="15"></td></tr>
	<br><br>
	</table>
	<center>
	<table>
	<tr><td></td><td><input type="submit" name="" value="Gravar"></td></tr>
	</table>
	</form>
	</center>
	<br><br><br>
	<a href="principal.php"> Voltar</a>
	</center>
</html>
